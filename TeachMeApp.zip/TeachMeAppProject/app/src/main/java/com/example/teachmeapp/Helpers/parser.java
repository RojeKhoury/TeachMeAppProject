package com.example.teachmeapp.Helpers;

import java.util.HashMap;

public class parser {
    public static HashMap<String, String> parseTeacher(String teacher)
    {
        HashMap<String, String> res = new HashMap<>();



        return res;
    }
}
