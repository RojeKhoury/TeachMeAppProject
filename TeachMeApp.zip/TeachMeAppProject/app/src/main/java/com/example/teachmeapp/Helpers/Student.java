package com.example.teachmeapp.Helpers;

import java.util.List;

public class Student {

    private String name;
    private String surname;
    private String phone;
    private List<Lesson> classes;
    private String email;
    private String uid;
    private location local;

    public Student() {
    }

    public Student(String name, String surname, String phone, List<Lesson> classes, String email, String uid, location local) {

        // [START_EXCLUDE]
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.classes = classes;
        this.email = email;
        this.uid = uid;
        this.local = local;

        // [END_EXCLUDE]
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getSurname() {
        return surname;
    }

    public String getPhone() {
        return phone;
    }

    public String getUid() {
        return uid;
    }

    public location getLocal() {
        return local;
    }

    public List<Lesson> getLessons() {
        return classes;
    }

}
